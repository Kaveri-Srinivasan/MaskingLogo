import os
import io
import re
import difflib
import pytesseract
import pandas as pd
from PIL import Image
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

# === CONFIGURATION ===
masking_folder = "."
excel_file = os.path.join(masking_folder, "ClientLogo.xlsx")
pptx_file = os.path.join(masking_folder, "12_2_Haleon_Proposal_CI.pptx")
default_logo_path = os.path.join(masking_folder, "logo.png")
output_pptx_path = os.path.join(masking_folder, "presentation_masked.pptx")

# ✅ Point pytesseract to the installed tesseract.exe
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# === STEP 1: Load Client Names from Excel ===
df = pd.read_excel(excel_file)
client_names = df['Client Name'].dropna().str.lower().tolist()
replacement_counts = {name: 0 for name in client_names}

# === STEP 2: Load Presentation ===
prs = Presentation(pptx_file)

def image_contains_client_text(image_blob, client_keywords):
    """Run OCR on image and fuzzy match to client names."""
    try:
        image = Image.open(io.BytesIO(image_blob))
        raw_text = pytesseract.image_to_string(image).lower()

        # Clean OCR text: remove non-alphanumeric
        cleaned_text = re.sub(r'[^a-z0-9]', '', raw_text)

        for client in client_keywords:
            matches = difflib.get_close_matches(client, [cleaned_text], cutoff=0.75)
            if matches:
                print(f"🔍 Fuzzy OCR matched: '{matches[0]}' ≈ '{client}'")
                return client
        return None
    except Exception as e:
        print(f"⚠️ OCR failed: {e}")
        return None

def replace_with_logo(slide, shape):
    """Replace the given shape with the default logo."""
    try:
        left, top, height = shape.left, shape.top, shape.height
        slide.shapes._spTree.remove(shape._element)
        slide.shapes.add_picture(default_logo_path, left, top, height=height)
        return True
    except Exception as e:
        print(f"⚠️ Error replacing shape: {e}")
        return False

# === STEP 3: Process Slides ===
for slide_num, slide in enumerate(prs.slides, start=1):
    print(f"\n📄 Slide {slide_num}:")
    for shape in list(slide.shapes):
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            print(f"🖼️ Checking picture: '{shape.name}'")

            matched_client = image_contains_client_text(shape.image.blob, client_names)
            if matched_client:
                if replace_with_logo(slide, shape):
                    print(f"✅ Replaced logo for '{matched_client}' on Slide {slide_num}")
                    replacement_counts[matched_client] += 1

# === STEP 4: Save Output ===
prs.save(output_pptx_path)
print(f"\n✅ Masked presentation saved to: {output_pptx_path}")

# === STEP 5: Print Summary ===
print("\n🔍 Replacement Summary:")
for client, count in replacement_counts.items():
    print(f"  → {client.title()}: {count} replacement(s)")
